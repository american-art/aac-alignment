__author__ = 'amandeep'

"""
USE THESE FOR HBASE
self.hbase_host = 'zk04.xdata.data-tactics-corp.com:2181'
self.hbase_table = 'test_ht_aman'
"""

"""
EXECUTE AS
spark-submit  --master local[*]     --executor-memory=4g     --driver-memory=4g    \
 --jars jars/elasticsearch-hadoop-2.2.0-m1.jar,jars/spark-examples_2.10-2.0.0-SNAPSHOT.jar,jars/random-0.0.1-SNAPSHOT-shaded.jar    \
   es2hbase.py     -hostname  els.istresearch.com -port 19200 \
   -username memex -password <es_password> -indexname <esindex> \
    -doctype <esdoctype> -hbasehostname <hbasehostname> \
    -hbasetablename <hbase_tablename>
"""


class ES(object):
    def __init__(self, spark_context, spark_conf, index, doc, es_hostname, es_port, es_username, es_password, es_ssl):
        self.name = "ES2HBase"
        self.sc = spark_context
        self.conf = spark_conf
        self.es_conf = {}
        self.es_conf['es.resource'] = index + "/" + doc
        self.es_conf['es.nodes'] = es_hostname + ":" + str(es_port)
        self.es_conf['es.index.auto.create'] = "no"
        self.es_conf['es.net.http.auth.user'] = es_username
        self.es_conf['es.net.http.auth.pass'] = es_password
        self.es_conf['es.net.ssl'] = es_ssl
        self.es_conf['es.nodes.discovery'] = "false"
        self.es_conf['es.http.timeout'] = "1m"
        self.es_conf['es.http.retries'] = "1"
        self.es_conf['es.nodes.client.only'] = "false"
        self.es_conf['es.nodes.wan.only'] = "true"


    def es2rdd(self, query):
        self.es_conf['es.query'] = query
        # print self.es_conf
        es_rdd = self.sc.newAPIHadoopRDD(inputFormatClass="org.elasticsearch.hadoop.mr.EsInputFormat",
                                         keyClass="org.apache.hadoop.io.NullWritable",
                                         valueClass="org.apache.hadoop.io.Text",
                                         conf=self.es_conf)

        # es_rdd.map(lambda x: json.dumps(ES2HBase.printable_doc(x))).saveAsTextFile('/tmp/cdr_v2_ads')
        return es_rdd

    def rdd2es(self, rdd, batch_size, uri="uri"):

        self.es_conf['es.batch.size.entries'] = batch_size
        self.es_conf['es.batch.size.bytes'] = str(int(batch_size)*1024)
        self.es_conf['es.mapping.id'] = "uri"
        self.es_conf['es.input.json'] = "true"
        print self.es_conf
        rdd.saveAsNewAPIHadoopFile(
                path='-',
                outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
                keyClass="org.apache.hadoop.io.NullWritable",
                valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",
                conf=self.es_conf)
        print "Done save to ES"